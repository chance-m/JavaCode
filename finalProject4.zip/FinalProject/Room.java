import java.awt.Color;   
import java.awt.Graphics;
import java.awt.Point;

//A reference is an address that indicates where an object's
//variables and methods are stored

public class Room implements Drawable { 
	//this is where the fields are made
	private Point pos;
	private Room exitEast;
	private Room exitWest;
	private Room exitNorth;
	private Room exitSouth;
	public static final int SIZE = 50;

	public Room(int x, int y) {

		//When a variable has no value, it considered to be null
		pos = new Point(x,y);
		exitEast = null; // set all the fields to null
		exitWest = null;
		exitNorth = null;
		exitSouth = null;
	}

	//this is where we make the relationship between rooms
	public void setEastExit(Room r) {
		exitEast = r;
		r.exitWest = this;
	}

	public void setNorthExit(Room r) {
		exitNorth = r;
		r.exitSouth = this;
	}
	//these are the setters
	public void setWestExit(Room r) {
		exitWest = r;
		r.exitEast = this;
	}

	public void setSouthExit(Room r) {
		exitSouth = r;
		r.exitNorth = this;
	}
	//this is where the doors are positioned 
	public void draw(Graphics g) {
		g.setColor(Color.magenta);
		g.drawRect(pos.x, pos.y, SIZE, SIZE);
		//this is where we draw the rooms
		if (exitNorth != null) {
			g.setColor(Color.lightGray);
			g.drawLine(pos.x+20, pos.y, pos.x+30, pos.y);
		}
		if (exitSouth != null) {
			g.setColor(Color.lightGray);
			g.drawLine(pos.x+20, pos.y+50, pos.x+30, pos.y+50);
		}

		if (exitEast != null) {
			g.setColor(Color.lightGray);
			g.drawLine(pos.x+50, pos.y+20, pos.x+50, pos.y+30);
		}
		if (exitWest != null) {
			g.setColor(Color.lightGray);
			g.drawLine(pos.x, pos.y+20, pos.x, pos.y+30);
		}

	}
	
	public Point getPosition() {
		return pos;
	}
	//this is where we make the boolean methods
	public boolean hasNorthExit() {
		if (exitNorth == null) {
			return false;
		} else {
			return true;
		}
	}

	public boolean hasSouthExit() {
		if (exitSouth == null) {
			return false;
		} else {
			return true;
		}
	}

	public boolean hasEastExit() {
		if (exitEast == null) {
			return false;
		} else {
			return true;
		}
	}
	//these are the getters
	public boolean hasWestExit() {
		if (exitWest == null) {
			return false;
		} else {
			return true;
		}
	}
	public Room getNorthExit() {
		return exitNorth;
	}
	public Room getSouthExit() {
		return exitSouth;
	}
	public Room getEastExit() {
		return exitEast;
	}
	public Room getWestExit() {
		return exitWest;
	}

}
