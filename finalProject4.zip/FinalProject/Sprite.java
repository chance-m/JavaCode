import java.awt.Graphics;
import java.awt.Point;

import javax.swing.ImageIcon;

//Abstract classes are classes that contain one or more abstract methods.
//An abstract method is a method that is declared, but contains no implementation.
//They cannot be instantiated, and require subclasses to provide implementations
//for abstract methods.
//Abstract classes can provide the implementation of interfaces,
//interfaces can't provide implementation of abstract classes
//Interface can only have abstract methods, Abstract classes can have either
//abstract or regular methods.
//Interface is a collection of abstract methods, it is a reference type.
public abstract class Sprite implements Drawable { 
	protected Room currentRoom;
	protected ImageIcon image;
	
	public Sprite() { //this is the constructor
		currentRoom = null;
		image = null;
	}

	//this is the first method
	//this sets the current room of the object passed into it
	public void setCurrentRoom(Room r) {
		currentRoom = r;
	}

	public Room getCurrentRoom() {
		return currentRoom;
	}

	//draw the icons that we use
	public void draw(Graphics g) {
		if(currentRoom != null) {
			Point p = currentRoom.getPosition();
			image.paintIcon(null, g, p.x+16, p.y+12);
		}
	}
	//this where we check to see if the rooms have exits to go 
	public void moveSouth() {
		if(currentRoom.hasSouthExit()) {
			setCurrentRoom(currentRoom.getSouthExit());
		}
	}
	public void moveNorth() {
		if(currentRoom.hasNorthExit()) {
			setCurrentRoom(currentRoom.getNorthExit());
		}
	}
	public void moveEast() {
		if(currentRoom.hasEastExit()) {
			setCurrentRoom(currentRoom.getEastExit());
		}
	}
	public void moveWest() {
		if(currentRoom.hasWestExit()) {
			setCurrentRoom(currentRoom.getWestExit());
		}
	}
	
	@Override //this is where the equals() method is overridden
	public boolean equals(Object o) {
		if (o instanceof Sprite) {
			Sprite other = (Sprite)o;
			return (this.getCurrentRoom() == other.getCurrentRoom());
		}
		return false;
	}

}
