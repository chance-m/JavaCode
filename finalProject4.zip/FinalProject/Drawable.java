import java.awt.Graphics;
//this is the interface
public interface Drawable {
	void draw(Graphics g); //use a semicolon "{" because it is an abstract method
}