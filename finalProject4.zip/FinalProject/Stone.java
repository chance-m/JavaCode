import javax.swing.ImageIcon;

public class Stone extends Sprite{
	public Stone() {
		//this is how you call the constructor from the parent class
		super();
		image = new ImageIcon("stone2.png");
	}
}
