import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.*;

public class Maze extends JPanel implements KeyListener {
	Room r1; //this is where we make each room a field
	Room r2;
	Room r3;
	Room r4;
	Room r5;
	Room r6;
	Room r7;
	Room r8;
	Room r9;
	Room r10;
	Room r11;
	Room r12;
	Room r13;
	Room r14;
	Room r15;
	Room r16;
	Room r17;
	Room r18;
	Room r19;
	Room r20;
	Room r21;
	Room r22;
	Room r23;
	Room r24;
	Room r25;
	David dav;
	Goliath gol;
	ArrayList<Stone> stones;
	ArrayList<Drawable> able;
	//this is where we instantiate each room
	public Maze() { 
		able = new ArrayList<Drawable>();
		r1 = new Room(10,10);
		r2 = new Room(70,10);
		r3 = new Room(130,10);
		r4 = new Room(190,10);
		r5 = new Room(250,10);
		r6 = new Room(10,70);
		r7 = new Room(70,70);
		r8 = new Room(130,70);
		r9 = new Room(190,70);
		r10 = new Room(250,70);
		r11 = new Room(10,130);
		r12 = new Room(70,130);
		r13 = new Room(130,130);
		r14 = new Room(190,130);
		r15 = new Room(250,130);
		r16 = new Room(10,190);
		r17 = new Room(70,190);
		r18 = new Room(130,190);
		r19 = new Room(190,190);
		r20 = new Room(250,190);
		r21= new Room(10,250);
		r22 = new Room(70,250);
		r23 = new Room(130,250);
		r24 = new Room(190,250);
		r25 = new Room(250,250);
		able.add(r1);
		able.add(r2);
		able.add(r3);
		able.add(r4);
		able.add(r5);
		able.add(r6);
		able.add(r7);
		able.add(r8);
		able.add(r9);
		able.add(r10);
		able.add(r11);
		able.add(r12);
		able.add(r13);
		able.add(r14);
		able.add(r15);
		able.add(r16);
		able.add(r17);
		able.add(r18);
		able.add(r19);
		able.add(r20);
		able.add(r21);
		able.add(r22);
		able.add(r23);
		able.add(r24);
		able.add(r25);
		r1.setSouthExit(r6);
		r4.setSouthExit(r9);
		r4.setEastExit(r5);
		r5.setSouthExit(r10);
		r6.setEastExit(r7);
		r7.setNorthExit(r2);
		r7.setSouthExit(r12);
		r7.setEastExit(r8);
		r8.setNorthExit(r3);
		r8.setEastExit(r9);
		r8.setSouthExit(r13);
		r9.setSouthExit(r14);
		r10.setSouthExit(r15);
		r11.setEastExit(r12);
		r11.setSouthExit(r16);
		r13.setEastExit(r14);
		r13.setSouthExit(r18);
		r15.setSouthExit(r20);
		r16.setEastExit(r17);
		r16.setSouthExit(r21);
		r17.setEastExit(r18);
		r18.setEastExit(r19);
		r19.setEastExit(r20);
		r20.setSouthExit(r25);
		r21.setEastExit(r22);
		r22.setEastExit(r23);
		r23.setEastExit(r24);
		r24.setEastExit(r25);
		able.add(dav = new David()); //instantiate the objects
		dav.setCurrentRoom(r16);
		able.add(gol = new Goliath());
		gol.setCurrentRoom(r3);
		stones = new ArrayList<>();
		Stone s1 = new Stone();
		Stone s2 = new Stone();
		Stone s3 = new Stone();
		Stone s4 = new Stone();
		Stone s5 = new Stone();
		able.add(s1);
		able.add(s2);
		able.add(s3);
		able.add(s4);
		able.add(s5);
		stones.add(s1);
		stones.add(s2);
		stones.add(s3);
		stones.add(s4);
		stones.add(s5);
		stones.get(0).setCurrentRoom(r2);
		stones.get(1).setCurrentRoom(r6);
		stones.get(2).setCurrentRoom(r12);
		stones.get(3).setCurrentRoom(r14);
		stones.get(4).setCurrentRoom(r24);
		addKeyListener(this);
	}

	//this is where we draw the background and each room
	@Override 
	public void paintComponent(Graphics g) {
		int w = getWidth();
		int h = getHeight();
		g.setColor(Color.lightGray);
		g.fillRect(0, 0, w, h);
		//loop through the Drawable ArrayList
		for(Drawable img : able) {
			img.draw(g);
		}	
		//this is where each room is drawn
//		r1.draw(g);
//		r2.draw(g);
//		r3.draw(g);
//		r4.draw(g);
//		r5.draw(g);
//		r6.draw(g);
//		r7.draw(g); 
//		r8.draw(g);
//		r9.draw(g);
//		r10.draw(g);
//		r11.draw(g);
//		r12.draw(g);
//		r13.draw(g);
//		r14.draw(g);
//		r15.draw(g);
//		r16.draw(g);
//		r17.draw(g);
//		r18.draw(g);
//		r19.draw(g);
//		r20.draw(g);
//		r21.draw(g);
//		r22.draw(g);
//		r23.draw(g);
//		r24.draw(g);
//		r25.draw(g);
//		dav.draw(g); //draw the icons
//		gol.draw(g);
//		stones.get(0).draw(g);
//		stones.get(1).draw(g);
//		stones.get(2).draw(g);
//		stones.get(3).draw(g);
//		stones.get(4).draw(g);
		requestFocusInWindow();
	}

	//this is where we make the window
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(330,350);
		window.setContentPane(new Maze());
		window.setVisible(true);
	}
	private void resetMaze() {
		dav.setCurrentRoom(r16);
		dav.reset();
		gol.setCurrentRoom(r3);
		stones.get(0).setCurrentRoom(r2);
		stones.get(1).setCurrentRoom(r6);
		stones.get(2).setCurrentRoom(r12);
		stones.get(3).setCurrentRoom(r14);
		stones.get(4).setCurrentRoom(r24);
	}

	//this is where we get the KeyEvent
	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		if (key == KeyEvent.VK_UP) {
			dav.moveNorth();
		} 
		if (key == KeyEvent.VK_DOWN) {
			dav.moveSouth();
		} 
		if (key == KeyEvent.VK_LEFT) {
			dav.moveWest();
		} 
		if (key == KeyEvent.VK_RIGHT) {
			dav.moveEast();
		}
		if (key == KeyEvent.VK_W) {
			gol.moveNorth();
		} 
		if (key == KeyEvent.VK_S) {
			gol.moveSouth();
		} 
		if (key == KeyEvent.VK_A) {
			gol.moveWest();
		} 
		if (key == KeyEvent.VK_D) {
			gol.moveEast();
		}//this is where the number pad arrows are used when numlock is off
		if (key == KeyEvent.VK_KP_UP) {
			dav.moveNorth();
		} 
		if (key == KeyEvent.VK_KP_DOWN) {
			dav.moveSouth();
		} 
		if (key == KeyEvent.VK_KP_LEFT) {
			dav.moveWest();
		} 
		if (key == KeyEvent.VK_KP_RIGHT) {
			dav.moveEast();
		}//this is where the numpad is used when numlock is on
		if (key == KeyEvent.VK_NUMPAD8) {
			dav.moveNorth();
		} 
		if (key == KeyEvent.VK_NUMPAD2) {
			dav.moveSouth();
		} 
		if (key == KeyEvent.VK_NUMPAD4) {
			dav.moveWest();
		} 
		if (key == KeyEvent.VK_NUMPAD6) {
			dav.moveEast();
		}
		for(Stone x : stones) {
			if(x.equals(dav)){
				dav.pickUpStone();
				x.setCurrentRoom(null);
			}
		}
		if(dav.equals(gol)) { //this is where the new method is called
			if(dav.isArmed() == true) {
				JOptionPane.showMessageDialog(null, "Congratulations David! You wrecked Goliath!");
				resetMaze();
			} else {
				JOptionPane.showMessageDialog(null, "Uh Oh! You were not prepared to face Goliath! Try again.");
				resetMaze();
			}
		}	
		repaint();
	}	
	//these are unused methods
	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void keyTyped(KeyEvent e) {}

}
