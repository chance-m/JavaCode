import javax.swing.ImageIcon;

public class Goliath extends Sprite {
	public Goliath() {
		//this is how you call the constructor from the parent class
		super();
		image = new ImageIcon("goliath.png");
	}
}
