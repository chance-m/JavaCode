import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;


public class MainTree extends JFrame {

	private Vis mainPanel;
	private String dir;
	//private File file;

	//Constructor
	public MainTree() {

		JMenuBar mb = setupMenu();
		setJMenuBar(mb);
		dir = "C:\\Users\\chanc\\OneDrive\\Desktop\\Simple GUI";
		mainPanel = new Vis();
		setContentPane(mainPanel);
		setSize(800,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Tree Map for the path: " + dir);
		setVisible(true);
		//file = new File(dir);
		//fileTest(file);
	}

	/**
	 * Creates the menu bar and associated submenu's
	 * @return
	 */
	private JMenuBar setupMenu() {
		//instantiate menubar, menus, and menu options
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenuItem choose = new JMenuItem("Choose file");
		JMenuItem none = new JMenuItem("No color");
		JMenuItem random = new JMenuItem("Random");
		JMenuItem permit = new JMenuItem("Permissions");

		//setup action listeners
		choose.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				var fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int choose = fc.showOpenDialog(MainTree.this);
				if (choose == JFileChooser.APPROVE_OPTION) {
					File f = fc.getSelectedFile();
					mainPanel.setRoot(f);
					setTitle("Tree Map for the path: " + f.getPath());
					repaint();
				}
			}
		});
		none.addActionListener(e -> mainPanel.removeColor());
		random.addActionListener(e -> mainPanel.randomColor());
		//now hook them all together
		menuBar.add(fileMenu);
		fileMenu.add(choose);
		fileMenu.add(none);
		fileMenu.add(random);

		return menuBar;
	}

	public void fileTest(File f) {
		var files = f.listFiles();
		int fileSize = f.listFiles().length;
		for (int i = 0; i < fileSize; i++) {
			System.out.println("File Contents: " + files[i]);
		}
	}

	public static void main(String[] args) {
		//this makes the GUI adopt the look-n-feel of the windowing system (Windows/X11/Mac)
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) { }

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MainTree();
			}
		});
	}
}