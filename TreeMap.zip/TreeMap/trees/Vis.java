import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.util.Random;

import javax.swing.JPanel;

public class Vis extends JPanel implements MouseMotionListener {
	
//	private String message;
	private Node root; 
	private String dir;
	private File file;
	private Color color;
	int r,g,b;
	Random rand;
	
	//Constructor
	public Vis() {
		super();
		dir = "C:\\Users\\chanc\\OneDrive\\Desktop\\Simple GUI";
		file = new File(dir);
		//"C:\\Users\\chanc\\OneDrive\\Desktop\\TestFolder"
		root = new Node(file);
		//root = new Node();
		addMouseMotionListener(this);
		color = Color.orange;
	}
	/**
	 * Draws the tree map
	 */
	@Override
	public void paintComponent(Graphics g1) {
		Graphics2D g = (Graphics2D) g1;
		g.setColor(Color.black);
		root.draw(g, 0, 0, getWidth(), getHeight(), "horizontal", color);
	}
	/**
	 * Sets the root file of the tree map to be drawn
	 * @param file
	 */
	public void setRoot(File file) {
		root = new Node(file);
		repaint();
	}
	public String nodePath(Node n) {
		String s = n.getPath();
		return s;
	}
	
	public void removeColor() {
		color = Color.white;
		repaint();
	}
	public void randomColor() {
		rand = new Random();
		r = rand.nextInt(255);
		b =rand.nextInt(255);
		g = rand.nextInt(255);
		Color ran = new Color(r, g, b);
		color = ran;
		repaint();
	}

	@Override
	public void mouseDragged(MouseEvent e) {}
	
	@Override
	public void mouseMoved(MouseEvent m) {
		Point p = new Point(m.getX(), m.getY());
		Node n = root.getNodeAt(p);
		setToolTipText("Path: " + nodePath(n));
		//System.out.println("TEST: " + nodePath(n));
	}
	
	
}
	