import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Node {

	private List<Node> children;
	private double totalSize;
	private File f;
	float r,gr,b;
	Random rand;
	Rectangle rec;
	Color newColor;

	/**
	 * Constructor takes in a file object and makes recursive calls
	 * @param f
	 */

	public Node() {
		children = new ArrayList<>();
	}
	public Node(File file) {		
		f = file;
		int date = (int) f.lastModified();
		rec = null;
		//sSystem.out.println("This is the file path: " + getPath());
		children = new ArrayList<>();
		if (file.isFile() == true) {
			totalSize = file.length();
			//System.out.println("File type: " + getFileType(file));
		} else {
			for(File sub : file.listFiles()) {
				Node d = new Node(sub); //this is a recursive call
				//System.out.println("Date last modified " + date);
				totalSize += d.totalSize;
				children.add(d);
			}
		}
	}
	/**
	 * Draws each rectangle based on orientation
	 * @param col2 
	 * @param g, top, left, width, height, orientation
	 */
	public void draw(Graphics g, double left, double top, double width, double height, String orientation, Color col) {
		double childHeight;
		double childWidth;
		rand = new Random();
		r = rand.nextFloat();
		b =rand.nextFloat();
		gr = rand.nextFloat();
		rec = new Rectangle((int)left, (int)top, (int)width, (int)height);
		Color rando = new Color(r, gr, b);
		newColor = col;
		if (children.isEmpty()) {
			//			g.setColor(Color.white);
			//			g.drawRect((int)left, (int)top, (int)width, (int)height);
			g.setColor(col);
			g.fillRect((int)left+1,(int)top-1 , (int)width-1, (int)height-1);

			//System.out.println("top: " + top + " left: " + left + " width:" + width + " height: " + height);
		}
		if (orientation.equals("vertical")) {
			for (Node child : children) {
				childHeight = ((child.totalSize/(double)totalSize) * height);
				child.draw(g, (double)left, (double)top, (double)width, (double)childHeight, "horizontal", newColor);
				top += childHeight;
				//System.out.println("left: " + left + " width: " + width + " Child height: " + childHeight);
				//System.out.println("File type: " + getFileType(child.f));
			}
		} 
		if(orientation.equals("horizontal")) {
			for(Node c : children) {
				childWidth = ((c.totalSize/(double)totalSize) * width);
				c.draw(g, (double)left, (double)top, (double)childWidth, height, "vertical", newColor);
				left += childWidth;
				//System.out.println("top: " + top + " height: " + height + " Child width " + childWidth);
				//System.out.println("File type: " + getFileType(c.f));
			}
		}
		//		for (Node child : children) {
		//			System.out.println("This is the file type of each file: " + getFileType(f));
		//		}
	}

	//returns path
	public String getPath() {
		String s = f.getPath();
		return s;
	}
	// gets the node at specific point, determines if mouse in inside the node
	public Node getNodeAt(Point p) {
		Node result = this;
		for(Node child : children) {
			if (child.rec.contains(p)) {
				result = child.getNodeAt(p);
			}
		}
		return result;
	}

	//gets the file type
	public String getFileType(File f) {
		String ex = "";
		int i = f.getPath().lastIndexOf('.');
		if (i >= 0) {
			ex = f.getPath().substring(i);
		}
		return ex;
	}

}

